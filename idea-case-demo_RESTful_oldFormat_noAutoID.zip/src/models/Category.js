export default class Category {

    constructor(id, name, budget) {
        this.id = id;
        this.name = name;
        this.budget = budget;
    }
}
import { combineReducers } from 'redux';

import categories from './categories';

const xyz = () => (
    combineReducers({
        categories,
    })
);

export default xyz;

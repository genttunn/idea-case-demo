React Introduction and Recap task

Starting point for the Redux task

New things that were learned while completing the React task = this template:
- How to export a single function separately
- How to create a tidy minimalistic model file
- How to separate components into more fine grain
- How to get more comfortable working with a multi-level directory structure
